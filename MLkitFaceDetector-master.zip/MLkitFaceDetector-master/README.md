# MLkitFaceDetector

Sample project to explain the barcode Face detection API from Firebase MLKit

![ScreenShot](https://droidmentor.com/wp-content/uploads/2018/11/mlkit_face_detection_example.jpg)

Using this you can also plot the contours

![ScreenShot](https://droidmentor.com/wp-content/uploads/2018/11/mlkit_face_contours_example-1.jpg)

**Note:**

Before executing the project you have to connect it to anyone of your Firebase Project.

For more information, check out my detailed guide here :  https://droidmentor.com/face-detector-using-firebase-mlkit/
